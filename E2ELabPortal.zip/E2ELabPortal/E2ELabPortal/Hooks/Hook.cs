﻿using System;
using System.Collections.Generic;
using System.Text;
using E2ELabPortal.Drivers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

using TechTalk.SpecFlow;

namespace E2ELabPortal.Hooks
{
    [Binding]
    public class Hook
    {
        private readonly Driver hookDriver;
        private readonly ConfigurationDriver hookConfigDriver;
        private readonly IWebDriver driver;

        public Hook(Driver driver, ConfigurationDriver configurationDriver)
        {
            hookDriver = driver;
            hookConfigDriver = configurationDriver;

        }

        [BeforeScenario]
        public void OpenPage()
        {

            hookDriver.CurrentDriver.Url = hookConfigDriver.BaseUrl;
            System.Threading.Thread.Sleep(1000);
            //hookDriver.CurrentDriver.SwitchTo().Frame("pop-frame00821307194511045");
            
            //hookDriver.Wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText("Agree and Proceed"))).Click(); 

        }

        public void ValidateTitle()
        {
            string res = hookDriver.Wait.Until(d => d.Title);
            Console.WriteLine(res);

        }

        public void Quit()
        {
            hookDriver.Dispose();
        }

    }
}
