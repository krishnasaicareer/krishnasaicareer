﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace E2ELabPortal.Pages
{
    public class GmaiSignIn
    {
        private readonly IWebDriver myDriver;
        public GmaiSignIn(IWebDriver driver)
        {
            myDriver = driver;
        }


        public IWebElement SignIn => myDriver.FindElement(By.LinkText("Sign in"));
    }

    

}
