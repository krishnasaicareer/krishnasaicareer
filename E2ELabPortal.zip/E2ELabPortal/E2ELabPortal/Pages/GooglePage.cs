﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;


namespace E2ELabPortal.Pages
{
    public class GooglePage
    {
        private readonly IWebDriver myDriver;
        public GooglePage(IWebDriver driver)
        {
            myDriver = driver;
        }

        public IWebElement Search => myDriver.FindElement(By.LinkText("Gmail"));

    }
}
