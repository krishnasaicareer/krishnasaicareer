﻿using System;
using TechTalk.SpecFlow;
using E2ELabPortal.Drivers;

namespace E2ELabPortal.Steps
{
    [Binding]
    public class GoogleSearch
    {
        private readonly GooglePageDriver gPagedriver;
        private readonly Driver dri;

        public GoogleSearch(GooglePageDriver pageDriver, Driver d)
        {
            gPagedriver = pageDriver;
            dri = d;
        }

        
        [Given(@"Browser is launched")]
        public OpenQA.Selenium.IWebDriver GivenBrowserIsLaunched()
        {
            return dri.CurrentDriver;
        }
        
        [When(@"Entered the text in search bar")]
        public void WhenEnteredTheTextInSearchBar()
        {
            gPagedriver.ClickSearch();
            gPagedriver.EnterText();
        }
        
        [Then(@"The text is filled with the text")]
        public void ThenTheTextIsFilledWithTheText()
        {
            string text = gPagedriver.GetText();
            Console.WriteLine(text);
        }
    }
}
