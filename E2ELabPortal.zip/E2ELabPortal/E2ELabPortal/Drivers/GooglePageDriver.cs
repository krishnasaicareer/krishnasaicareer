﻿using System;
using System.Collections.Generic;
using System.Text;
using E2ELabPortal.Pages;

namespace E2ELabPortal.Drivers
{
    public class GooglePageDriver
    {
        private readonly Driver myDriver;
        GooglePage gp;
        public GooglePageDriver(Driver driver)
        {
            myDriver = driver;
           gp = new GooglePage(myDriver.CurrentDriver);
        }

        
        public void ClickSearch()
        {
            
            
            gp.Search.Click();
        }

        public void EnterText()
        {
            
            gp.Search.SendKeys("Hi");
        }

        public string GetText()
        {
            
            return gp.Search.Text;
        }

        


    }
}
