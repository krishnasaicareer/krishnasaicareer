﻿using System;
using System.Collections.Generic;
using System.Text;
using E2ELabPortal.Pages;

namespace E2ELabPortal.Drivers
{
    class GmailSignInPageDriver
    {
        private readonly Driver myDriver;
        GmaiSignIn gs;

        public GmailSignInPageDriver(Driver d)
        {
            myDriver = d;
            gs = new GmaiSignIn(myDriver.CurrentDriver);
        }

    }
}
