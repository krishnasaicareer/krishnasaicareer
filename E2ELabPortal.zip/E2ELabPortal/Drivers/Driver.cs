﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace E2ELabPortal.Drivers
{
    public class Driver : IDisposable
    {

        private readonly BrowserDriver webDriver;
        private readonly Lazy<IWebDriver> currentDriverInstance;
        private readonly Lazy<WebDriverWait> wait;
        private readonly TimeSpan waitTime = TimeSpan.FromSeconds(30);
        

        public Driver(BrowserDriver browserDriver)
        {
            webDriver = browserDriver;
            currentDriverInstance = new Lazy<IWebDriver>(GetWebDriver);
            wait = new Lazy<WebDriverWait>(GetWebDriverWait);
        }

        #region Getters
        public IWebDriver CurrentDriver => currentDriverInstance.Value;
        public WebDriverWait Wait => wait.Value;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns>WebDriverWait</returns>
        private WebDriverWait GetWebDriverWait()
        {
            return new WebDriverWait(CurrentDriver, waitTime);
        }

        /// <summary>
        /// Gets the browser
        /// </summary>
        /// <returns>IWebDriver</returns>
        private IWebDriver GetWebDriver()
        {
            string browserType = Environment.GetEnvironmentVariable("Test_Browser");

            
            return webDriver.GetBrowser(browserType);
        }

      
        public void Dispose()
        {
            if(currentDriverInstance.IsValueCreated)
            {
                CurrentDriver.Quit();
            }
            else
            {
                return;
            }
        }
    }
}
