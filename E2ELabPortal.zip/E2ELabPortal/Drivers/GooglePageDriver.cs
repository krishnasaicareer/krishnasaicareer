﻿using System;
using System.Collections.Generic;
using System.Text;
using E2ELabPortal.Pages;

namespace E2ELabPortal.Drivers
{
    public class GooglePageDriver
    {
        private readonly Driver myDriver;
        public GooglePageDriver(Driver driver)
        {
            myDriver = driver;
            
        }

        public void ClickSearch()
        {
            GooglePage gp = new GooglePage(myDriver.CurrentDriver);
            
            gp.Search.Click();
        }

        public void EnterText()
        {
            GooglePage gp = new GooglePage(myDriver.CurrentDriver);
            gp.Search.SendKeys("Hi");
        }

        public string GetText()
        {
            GooglePage gp = new GooglePage(myDriver.CurrentDriver);
            return gp.Search.Text;
        }

        


    }
}
